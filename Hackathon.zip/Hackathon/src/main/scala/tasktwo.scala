

object tasktwo extends App {

  var rangeOrder = Seq[(Int,Int)]()  // sequence to store the range order
  var maxTuples = Seq[(Int,Int)]()
  var orderStartSeq=Seq[Int]()       //order start sequence unique
  //var maxDiffTuple:((Int,Int),Int)=null
  val N: Int = scala.io.StdIn.readInt();
  val orderString : Array[String] = scala.io.StdIn.readLine().trim().split(" ");
  val Q: Int = scala.io.StdIn.readInt();
  var orderMap = Map[Int,Seq[(Int,Int)]]() //map to store the index and the associated order types


  //loop to generate the range order sequence and order start sequence
  for (loop <- 1 to Q) {
    val input = scala.io.StdIn.readLine().trim().split(" ")
    rangeOrder=rangeOrder:+(input(0).toInt,input(1).toInt)
    orderStartSeq=orderStartSeq:+input(0).toInt
  }

           //println(rangeOrder)
          //orderString.foreach(println)

  //Generate the order map for the values
  for (item <- orderStartSeq.distinct ){
    orderMap =orderMap+(item->(rangeOrder.filter(tup=>tup._1==item)))
  }


  //find out the maxi mum range for each of the unique order starting point
  for ((k,v) <- orderMap){
    val keyOrderEndPoints = v.map(tup=>tup._2)
    maxTuples =maxTuples:+(k,keyOrderEndPoints.max)
  }

  //create the final index of sums depending of the structure for quick lookups (key -> List of sums as per the max range )
  //println("The Final Tuples with max range is ",maxTuples)

  var sumMap = Map[Int,Seq[Int]]()

  for (rangeTuple <- maxTuples){
    var sum: Int = 0
    var sumSeq = Seq[Int]()
      for (rangePerTuple <-  rangeTuple._1 to rangeTuple._2 ){
        sum = sum + orderString(rangePerTuple-1).toInt
        sumSeq=sumSeq:+sum
      }
    sumMap = sumMap+(rangeTuple._1->sumSeq)
  }

      //  for ((k,v)<-sumMap){
      //    println(k+"->",v)
      //  }

  //print the sum of the order as per required
  for (tup <- rangeOrder){
    println(sumMap(tup._1)(Math.abs(tup._1-tup._2)))
  }
}
